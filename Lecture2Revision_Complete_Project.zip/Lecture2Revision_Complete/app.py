import re
import random
import streamlit as st

st.set_page_config(page_title="Lecture2Revision | AI Study Assistant", page_icon="📚", layout="wide")
st.title("📚 Lecture2Revision")
st.subheader("Convert lectures into adaptive revision material")
st.write("Generate a summary, revision notes, a practice quiz, and a learning-trend estimate.")

@st.cache_resource(show_spinner=False)
def load_transformer():
    from transformers import pipeline
    return pipeline("summarization", model="sshleifer/distilbart-cnn-12-6")

def clean(text):
    return re.sub(r"\s+", " ", text).strip()

def split_sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", clean(text)) if len(s.split()) >= 5]

def fallback_summary(text, limit=5):
    ss = split_sentences(text)
    if not ss:
        return clean(text)[:700]
    keywords = {"important","because","therefore","example","process","method","system","data","model","result","learning","memory","algorithm","function"}
    scored=[]
    for i,s in enumerate(ss):
        words=re.findall(r"\b[a-zA-Z]{3,}\b",s.lower())
        scored.append((sum(w in keywords for w in words)+min(len(words),25)/25,i,s))
    return " ".join(x[2] for x in sorted(sorted(scored, reverse=True)[:limit],key=lambda x:x[1]))

def make_quiz(text, number=6):
    stop={"this","that","with","from","have","were","will","their","there","which","about","into","also","they","them","then","than","when","what","where","your","used","using","because","been","being","each","such","these","those","have","does","more","most","some","very"}
    out=[]
    for sentence in split_sentences(text):
        words=re.findall(r"\b[A-Za-z][A-Za-z-]{3,}\b",sentence)
        candidates=[]
        for w in words:
            if w.lower() not in stop and w.lower() not in [x.lower() for x in candidates]:
                candidates.append(w)
        if len(candidates)<4: continue
        answer=max(candidates,key=lambda w:(len(w),w.lower()))
        question=re.sub(r"\b"+re.escape(answer)+r"\b","________",sentence,count=1,flags=re.I)
        distractors=[w for w in candidates if w.lower()!=answer.lower()]
        distractors=sorted(distractors,key=lambda w:abs(len(w)-len(answer)))
        options=[answer]+distractors[:3]
        while len(options)<4: options.append("Not mentioned")
        random.Random(len(sentence)).shuffle(options)
        out.append({"question":question,"options":options[:4],"answer":answer})
        if len(out)>=number: break
    return out

def read_pdf(file):
    from pypdf import PdfReader
    return "\n".join(page.extract_text() or "" for page in PdfReader(file).pages)

# LSTM model: trains on generated example score histories for a demonstrative trend classifier.
# This is a working ML component, but the synthetic data is not a substitute for real student records.
@st.cache_resource(show_spinner=False)
def train_lstm_demo():
    import torch
    from torch import nn
    import numpy as np
    torch.manual_seed(17)
    rng=np.random.default_rng(17)
    X=[]; y=[]
    # Labels: 0=needs revision, 1=improving, 2=strong/steady
    for _ in range(900):
        start=float(rng.uniform(15,90))
        trend=float(rng.uniform(-12,15))
        noise=rng.normal(0,5,5)
        scores=np.clip(start+np.arange(5)*trend+noise,0,100)
        delta=scores[-1]-scores[0]
        if scores[-1] < 55: label=0
        elif delta >= 8: label=1
        else: label=2
        X.append(scores/100.0); y.append(label)
    X=torch.tensor(np.array(X),dtype=torch.float32).unsqueeze(-1)
    y=torch.tensor(np.array(y),dtype=torch.long)
    class ScoreLSTM(nn.Module):
        def __init__(self):
            super().__init__()
            self.lstm=nn.LSTM(input_size=1,hidden_size=16,batch_first=True)
            self.fc=nn.Linear(16,3)
        def forward(self,x):
            out,_=self.lstm(x)
            return self.fc(out[:,-1,:])
    model=ScoreLSTM()
    opt=torch.optim.Adam(model.parameters(),lr=0.01)
    loss_fn=nn.CrossEntropyLoss()
    model.train()
    for _ in range(70):
        opt.zero_grad()
        loss=loss_fn(model(X),y)
        loss.backward()
        opt.step()
    model.eval()
    return model

def predict_trend(scores):
    import torch
    model=train_lstm_demo()
    x=torch.tensor(scores,dtype=torch.float32).reshape(1,len(scores),1)/100.0
    with torch.no_grad():
        probs=torch.softmax(model(x),dim=1)[0]
    idx=int(torch.argmax(probs))
    labels=["Needs revision","Improving","Strong / steady"]
    messages=[
        "Revise the key concepts, then attempt a short quiz again.",
        "Your recent scores suggest improvement. Keep practising weak topics.",
        "Your score pattern looks steady. Try a harder quiz to check deeper understanding."
    ]
    return labels[idx], messages[idx], float(probs[idx])

with st.sidebar:
    st.header("Project components")
    st.markdown("- **Transformer:** lecture summarization\n- **LSTM:** quiz-score sequence trend\n- **Quiz engine:** practice questions\n- **PDF/TXT upload:** lecture input")
    st.caption("First Transformer run downloads a pretrained model and requires internet.")
    st.warning("LSTM demo trains on synthetic sample score histories. For reliable predictions, train/validate it on real, consented student data.")

tab1,tab2=st.tabs(["✍️ Paste lecture","📄 Upload file"])
with tab1:
    pasted=st.text_area("Paste lecture content",height=230,placeholder="Paste your lecture notes here (at least 25 words).")
with tab2:
    uploaded=st.file_uploader("Upload a text-based PDF or TXT file",type=["txt","pdf"])
    uploaded_text=""
    if uploaded:
        try:
            uploaded_text=uploaded.read().decode("utf-8",errors="ignore") if uploaded.name.lower().endswith(".txt") else read_pdf(uploaded)
            st.success(f"Loaded {uploaded.name}")
            if not uploaded_text.strip(): st.warning("No text found. Scanned/image PDFs may need OCR.")
        except Exception as e:
            st.error(f"Could not read file: {e}")

col1,col2=st.columns(2)
with col1:
    use_transformer=st.checkbox("Use pretrained Transformer (DistilBART)",value=True)
with col2:
    quiz_count=st.slider("Number of quiz questions",min_value=3,max_value=8,value=5)
st.caption("If the Transformer cannot load, the app falls back to an extractive summary.")
if st.button("✨ Generate revision material",type="primary",use_container_width=True):
    text=clean(uploaded_text or pasted or "")
    if len(text.split())<25:
        st.warning("Please provide at least about 25 words of lecture content.")
    else:
        summary=""
        method=""
        if use_transformer:
            try:
                with st.spinner("Loading Transformer and generating summary (first run may take a few minutes)..."):
                    summarizer=load_transformer()
                    chunks=[" ".join(text.split()[i:i+420]) for i in range(0,len(text.split()),420)]
                    parts=[]
                    for chunk in chunks[:8]:
                        if len(chunk.split())<25: parts.append(chunk); continue
                        parts.append(summarizer(chunk,max_length=min(130,max(45,len(chunk.split())//2)),min_length=20,do_sample=False,truncation=True)[0]["summary_text"])
                    summary=" ".join(parts)
                    method="Pretrained Transformer: DistilBART"
            except Exception as e:
                st.warning("Transformer could not load; using fallback summary. Check internet/package setup.")
                st.caption(str(e)[:500])
        if not summary:
            summary=fallback_summary(text)
            method="Extractive fallback (rule-based)"
        st.session_state["lecture"]=text
        st.session_state["summary"]=summary
        st.session_state["method"]=method
        st.session_state["quiz"]=make_quiz(text,quiz_count)
        st.session_state["quiz_answers"]={}

if "summary" in st.session_state:
    st.divider()
    st.subheader("1. Lecture summary")
    st.caption("Method: "+st.session_state["method"])
    st.write(st.session_state["summary"])
    st.subheader("2. Quick revision notes")
    notes=split_sentences(st.session_state["summary"])
    if notes:
        for i,s in enumerate(notes,1): st.markdown(f"{i}. {s}")
    else: st.write(st.session_state["summary"])
    st.subheader("3. Practice quiz")
    quiz=st.session_state.get("quiz",[])
    if not quiz:
        st.info("No quiz questions could be generated. Add more complete sentences to the lecture.")
    else:
        with st.form("quiz_form"):
            answers=[]
            for i,q in enumerate(quiz):
                st.markdown(f"**Q{i+1}. {q['question']}**")
                answers.append(st.radio("Choose one",q["options"],key=f"quiz_{i}"))
            submitted=st.form_submit_button("Check answers")
        if submitted:
            score=sum(a.lower()==q["answer"].lower() for a,q in zip(answers,quiz))
            st.session_state["last_score"]=score
            st.session_state["last_total"]=len(quiz)
            st.session_state["last_answers"]=answers
            st.metric("Quiz score",f"{score} / {len(quiz)}")
            with st.expander("Show correct answers"):
                for i,(q,a) in enumerate(zip(quiz,answers),1):
                    st.write(f"Q{i}: Correct answer: **{q['answer']}** — "+("Correct" if a.lower()==q["answer"].lower() else "Review this concept"))
            if score < len(quiz): st.info("Review the notes and retry the quiz.")
            else: st.success("Great! All answers correct.")
    st.divider()
    st.subheader("4. LSTM adaptive revision suggestion")
    st.write("Enter your last 5 quiz percentages in chronological order (oldest to newest).")
    score_input=st.text_input("Past scores, comma-separated",value="45, 50, 58, 62, 70",help="Example: 45,50,58,62,70")
    if st.button("Analyze score trend with LSTM"):
        try:
            scores=[float(x.strip()) for x in score_input.split(",") if x.strip()]
            if len(scores)!=5 or any(x<0 or x>100 for x in scores):
                st.error("Enter exactly 5 scores between 0 and 100, separated by commas.")
            else:
                with st.spinner("Training/loading LSTM demo and analysing scores..."):
                    label,msg,confidence=predict_trend(scores)
                st.metric("LSTM trend category",label)
                st.write(msg)
                st.caption(f"Model confidence for this category: {confidence:.0%}. Demo model trained on synthetic data; this confidence is not a validated academic prediction.")
        except Exception as e:
            st.error("LSTM analysis failed. Check that PyTorch is installed. Details: "+str(e)[:400])
    st.caption("Educational prototype: review generated summaries/questions before relying on them. PDF extraction works for text-based PDFs, not scanned images.")
