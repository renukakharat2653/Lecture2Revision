# Lecture2Revision — Complete Mini-Hackathon Project

**Problem statement:** Convert lecture content into adaptive revision material.

## Features
1. Paste lecture notes or upload a text-based PDF/TXT.
2. Transformer summarization using pretrained DistilBART (`sshleifer/distilbart-cnn-12-6`).
3. Extractive fallback summary if the Transformer cannot download/load.
4. Revision notes from the generated summary.
5. Automatic fill-in-the-blank practice quiz and score feedback.
6. PyTorch LSTM that analyses a sequence of five quiz scores and gives a revision trend category.

## Important LSTM note
The LSTM is a real PyTorch LSTM trained when first needed, but this starter demo trains it on **synthetic generated score sequences**, not a real student dataset. Its predictions are only a demonstration of the adaptive-learning concept. For a research-grade result, collect consented student quiz histories and train/test/validate the model on separate real data.

## Recommended setup
Use **Python 3.11** on Windows for better compatibility with PyTorch and Transformers.

1. Extract this ZIP.
2. Open the extracted `Lecture2Revision_Complete` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

5. Open the local URL shown in the terminal, usually `http://localhost:8501`.
6. Paste lecture content (at least 25 words) or upload a TXT/text-based PDF, then click **Generate revision material**.
7. Enter five quiz percentages such as `45, 50, 58, 62, 70` and click **Analyze score trend with LSTM**.

### If PowerShell blocks activation
Run this in the same terminal, then activate again:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

### First run
The pretrained Transformer downloads model files from Hugging Face, so internet is required for the first Transformer summary. It may take several minutes and requires disk space. Uncheck the Transformer option to use the local fallback summary if needed.

### Project architecture
- `app.py` — Streamlit UI, file reading, summary, quiz and LSTM analysis.
- `requirements.txt` — Python dependencies.
- `sample_data/sample_lecture.txt` — sample lecture text for testing.

## Technologies
Python, Streamlit, Hugging Face Transformers (DistilBART), PyTorch LSTM, pypdf.

## Demo limitation
Quiz generation and fallback summarization use simple rules. Generated content can be imperfect; review it before using it for exam preparation.
